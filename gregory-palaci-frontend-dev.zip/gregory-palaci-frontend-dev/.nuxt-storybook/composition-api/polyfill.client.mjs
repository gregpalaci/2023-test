// Necessary polyfill for Composition API support for IE11
import 'core-js/features/reflect/own-keys'
