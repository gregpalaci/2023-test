export const isFullStatic = false
export const staticPath = "/Users/carflow/Sites/JET/.nuxt/static-json"
export const publicPath = "/"
export const globalContext = "__NUXT__"
export const globalNuxt = "$nuxt"