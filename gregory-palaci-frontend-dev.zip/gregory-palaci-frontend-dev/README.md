````yarn to install```
and 
```yarn dev to run```