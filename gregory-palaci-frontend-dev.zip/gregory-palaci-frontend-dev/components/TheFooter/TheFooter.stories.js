export default {
    title: 'TheFooter',
  };
  
  export const TheFooter = () => '<TheFooter />';
  
  