// Used for __tests__/testing-library.js
// allows you to do things like:
// expect(element).toHaveTextContent('hi!')
// Learn more: https://github.com/testing-library/jest-dom
import '@testing-library/jest-dom';
