import Vue from 'vue'

import StarRating from 'vue-dynamic-star-rating'

Vue.component('StarRating', StarRating);
