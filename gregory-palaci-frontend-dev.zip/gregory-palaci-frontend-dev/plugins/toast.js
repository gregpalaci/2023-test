// register the plugin on vue
import Vue from 'vue'
import Toasted from 'vue-toasted';

// or you can use it with require
Vue.use(Toasted)
