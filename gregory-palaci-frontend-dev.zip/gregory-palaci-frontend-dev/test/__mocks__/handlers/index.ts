import { greetingMock } from './greeting';

export const handlers = [greetingMock];
